/**
 * Copyright (C) 2010 the original author or authors.
 * See the notice.md file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.beust.jcommander.internal;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Maps {

  public static <K, V> Map<K,V> newHashMap() {
    return new HashMap<>();
  }

  public static <K, V> Map<K,V> newLinkedHashMap() {
    return new LinkedHashMap<>();
  }

  public static <T> Map<T, T> newHashMap(T... parameters) {
    Map<T, T> result = Maps.newHashMap();
    for (int i = 0; i < parameters.length; i += 2) {
      result.put(parameters[i], parameters[i + 1]);
    }
    return result;
  }

}
